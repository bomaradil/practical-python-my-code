#setup.py

import setuptools

setuptools.setup(
    name="porty",
    version="0.0.1",
    authot="Boa",
    author_mail="b.omaradil@gmail.com",
    description="Practical Python code",
    packages=setuptools.find_packages(),
)